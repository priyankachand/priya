package shopify.Controller;
import java.io.File;
import java.nio.file.Path;
import java.nio.file.Paths;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.ModelAndView;
import shopify.DAO.*;
import shopify.Model.*;


@Controller
public class BaseController {

	@Autowired
	ProdModelDAO sd;
	@Autowired
	AddProductDAO ap;
	@Autowired
	AddressDAO ad;
	@Autowired
	BillingAddressDAO ba;
	ModelAndView m;
	
	@ModelAttribute("staffobj")
	public ProdModel getProdModel(){
		return new ProdModel();
	}
	@ModelAttribute("pobj")
	public AddProduct getProducts(){
		return new AddProduct();
	}
	
	@ModelAttribute("addressobj")
	public Address getAddress(){
		return new Address();
	}
	
	@ModelAttribute("baddressobj")
	public Address getBillingAddress(){
		return new Address();
	}
    @RequestMapping("/")
    public String gouserprofile1() {
    System.out.println("index");
    return "index";
    }
    
    @RequestMapping("/login")
    public String gouserprofile5() {
    System.out.println("login");
    return "login";
    }
    
    @RequestMapping("/save")
	public ModelAndView addC(@Valid @ModelAttribute("staffobj")ProdModel x,BindingResult br){
		if(br.hasErrors()){
			m= new ModelAndView("registration");
			
			m.addObject("staffobj", x);
			return m;
		}
				
			m = new ModelAndView("login");
			
			 String emailregex = "^[_A-Za-z0-9-]+(\\.[_A-Za-z0-9-]+)*@[A-Za-z0-9-]+(\\.[A-Za-z0-9-]+)*(\\.[A-Za-z]{2,})$";
			 if(x.getPassword().equals(x.getRepassword())&&x.getEmail().matches(emailregex))
			 {
				 sd.addProdModel(x);
			 }
			 else
			 {
				 m= new ModelAndView("registration");
			     m.addObject("staffobj", x);
				return m; 
			 }		
			return m;
	}
    
    @RequestMapping("/Add")
   	public String goStore1(@ModelAttribute("pobj")AddProduct x, HttpServletRequest req){
   		ap.addProduct(x);
   		MultipartFile itemImage = x.getFile();
        String rootDirectory = req.getSession().getServletContext().getRealPath("/");
        File f = new File(rootDirectory + "Resources\\images\\");
        if(!f.exists())
        f.mkdirs();
        Path path = Paths.get(rootDirectory +
"Resources\\images\\"+x.getPid()+".jpg");

        if (itemImage != null && !itemImage.isEmpty()) {
            try {
            itemImage.transferTo(new File(path.toString()));
            System.out.println("Image Uploaded - "+rootDirectory +
"Resources\\images\\"+x.getPid()+".jpg");
            } catch (Exception e) {
                e.printStackTrace();
                throw new RuntimeException("item image saving failed.", e);
            }
        }
   		return "redirect:/AddProduct";
   	}
    @RequestMapping("/store")
	public String goSore(@ModelAttribute("addressobj")Address x2){ 
		ad.addAddress(x2);
		return "address";
    }
    
    /*@RequestMapping("/view")
	public ModelAndView viewUser(){
		ModelAndView m = new ModelAndView("viewUser");
		m.addObject("data", sd.viewAllProdModels());
		return m;
	}*/
    
    @RequestMapping("/viewallproducts")
	public ModelAndView goviewproducts() {
	System.out.println("viewallproduct");
   ModelAndView view=new ModelAndView("viewallproducts");
	view.addObject("data", sd.viewAllProdModels());	
	return view;
	}
	@RequestMapping("/viewad/{id}")
	public ModelAndView goviewproduct(@PathVariable("id")int id) {
	System.out.println(id);
	ModelAndView view=new ModelAndView("viewproducts");
	view.addObject("data", sd.viewProdModelById( id));	
	return view;
	}
   
    @RequestMapping("/AddProduct")
    public String goAddProduct(@ModelAttribute("pobj")AddProduct x) {
    System.out.println("AddProduct");
    return "AddProduct";
    }
    
    @RequestMapping("/cancelled")
    public String cancelled() {
    System.out.println("cancelled");
    return "cancelled";
    }


	@RequestMapping("/finish")
    public String finish() {
    System.out.println("finish");
    return "finish";
    }

    
    @RequestMapping("/logout")
 	public ModelAndView handleRequest(HttpServletRequest request, HttpServletResponse response){
 	ModelAndView view = new ModelAndView("index");
 	request.getSession().invalidate();
 	return view;
 	} 
      
    @RequestMapping("/register")
    public String gouserprofile2() {
    System.out.println("register");
    return "register";
    }

    @RequestMapping("/contact")
    public String gouserprofile3() {
    System.out.println("contacts");
    return "contact";
    }
    
    @RequestMapping("/checkout")
    public String gouserprofile4() {
    System.out.println("checkout");
    return "checkout";
    }
       
    @RequestMapping("/single")
    public String gouserprofile6() {
    System.out.println("single");
    return "single";
    }
    @RequestMapping("/products")
	public String goproducts() {
	System.out.println("products");
	return "products";
	}
    @RequestMapping("/welcome")
	public String gowelcome() {
	System.out.println("welcome");
	return "welcome";
	}
    @RequestMapping("/w")
	public String goAddress() {
	System.out.println("Address");
	return "address";
	}
    @RequestMapping("/stor")
	public String goBillingAddress() {
	System.out.println("Billing Address");
	return "billingaddress";
	}
	
		
}