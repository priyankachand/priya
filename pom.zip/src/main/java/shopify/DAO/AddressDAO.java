package shopify.DAO;
import java.util.List;

import shopify.Model.Address;
public interface AddressDAO {
	void addAddress(Address s2);
	void delAddress(int aid);
	void updAddress(Address s2);
	Address viewAddModelById(int aid);
	List<Address> viewAllProducts();


}
