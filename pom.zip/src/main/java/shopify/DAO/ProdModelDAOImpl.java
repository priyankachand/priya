package shopify.DAO;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import shopify.Model.ProdModel;

@Repository
public class ProdModelDAOImpl implements ProdModelDAO {

	@Autowired
	SessionFactory sf;
	
	Session ss;
	Transaction t;
	
	public void addProdModel(ProdModel s) {
		// TODO Auto-generated method stub
		ss = sf.openSession();
		t = ss.beginTransaction();
		ss.save(s);
		t.commit();
	}

	public void delProdModel(String fname) {
		// TODO Auto-generated method stub
		ss = sf.openSession();
		t = ss.beginTransaction();
		ProdModel x = (ProdModel)ss.load(ProdModel.class,fname);
		ss.delete(x);
		t.commit();
	}

	
	public void updProdModel(ProdModel s) {
		// TODO Auto-generated method stub
		ss = sf.openSession();
		t = ss.beginTransaction();
		ProdModel x = (ProdModel)ss.load(ProdModel.class,s.getFname());
		x.setFname(s.getFname());
		x.setLname(s.getLname());
		x.setEmail(s.getEmail());
		x.setPassword(s.getPassword());
		x.setRepassword(s.getRepassword());
		x.setNumber(s.getNumber());
		ss.saveOrUpdate(x);
		t.commit();
	}

	
	public ProdModel viewProdModelById(String fname) {
		// TODO Auto-generated method stub
		ss = sf.openSession();
		t = ss.beginTransaction();
		ProdModel x = (ProdModel)ss.load(ProdModel.class,fname);
		t.commit();
		return x;
	}

	
	public List<ProdModel> viewAllProdModels() {
		// TODO Auto-generated method stub
		ss = sf.openSession();
		t = ss.beginTransaction();
		List<ProdModel> l = ss.createCriteria(ProdModel.class).list();
		t.commit();
		return l;
	}

	
	public ProdModel viewProdModelById(int id) {
		// TODO Auto-generated method stub
		return null;
	}

}

