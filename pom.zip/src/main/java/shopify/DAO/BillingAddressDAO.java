package shopify.DAO;
import java.util.List;

import shopify.Model.Address;
import shopify.Model.BillingAddress;
public interface BillingAddressDAO {
	void addBillingAddress(Address s2);
	void delBillingAddress(int aid);
	void updBillingAddress(Address s2);
	BillingAddress viewAddModelById(int aid);
	List<BillingAddress> viewAllAddress();


}
