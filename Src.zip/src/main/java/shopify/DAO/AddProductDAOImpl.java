package shopify.DAO;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import shopify.Model.AddProduct;

@Repository
public class AddProductDAOImpl implements AddProductDAO {

	@Autowired
	SessionFactory sf;
	
	Session ss;
	Transaction t;
	
	public void addProduct(AddProduct s) {
		// TODO Auto-generated method stub
		ss = sf.openSession();
		t = ss.beginTransaction();
		ss.save(s);
		t.commit();
	}

	/*public void AddProduct(String fname) {
		// TODO Auto-generated method stub
		ss = sf.openSession();
		t = ss.beginTransaction();
		AddProduct x = (AddProduct)ss.load(AddProduct.class,fname);
		ss.delete(x);
		t.commit();
	}*/

	
	public void updProduct(AddProduct p) {
		// TODO Auto-generated method stub
		ss = sf.openSession();
		t = ss.beginTransaction();
		AddProduct x = (AddProduct)ss.load(AddProduct.class,p.getPid());
		x.setPid(p.getPid());
		x.setPname(p.getPname());
		x.setQuantity(p.getQuantity());
		x.setDescription(p.getDescription());
		ss.saveOrUpdate(x);
		t.commit();
	}

	
	public AddProduct viewProdModelById(int pid) {
		// TODO Auto-generated method stub
		ss = sf.openSession();
		t = ss.beginTransaction();
		AddProduct x = (AddProduct)ss.load(AddProduct.class,pid);
		t.commit();
		return x;
	}

	
	public List<AddProduct> viewAllProducts() {
		// TODO Auto-generated method stub
		ss = sf.openSession();
		t = ss.beginTransaction();
		List<AddProduct> l = ss.createCriteria(AddProduct.class).list();
		t.commit();
		return l;
	}

	@Override
	public void delProduct(String pid) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public AddProduct viewProductById(String pid) {
		// TODO Auto-generated method stub
		return null;
	}

	

	
}

