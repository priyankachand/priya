package shopify.DAO;

import java.util.List;

import shopify.Model.ProdModel;

public interface ProdModelDAO 

{
	
	void addProdModel(ProdModel s);
	void delProdModel(String fname);
	void updProdModel(ProdModel s);
	ProdModel viewProdModelById(String fname);
	List<ProdModel> viewAllProdModels();


}
