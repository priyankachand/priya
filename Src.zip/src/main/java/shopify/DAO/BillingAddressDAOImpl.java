package shopify.DAO;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import shopify.Model.Address;
@Repository
public class BillingAddressDAOImpl implements AddressDAO {
	@Autowired
	SessionFactory sf2;
	
	Session ss2;
	Transaction t3;

	public void addAddress(Address s2) {
		// TODO Auto-generated method stub
		ss2 = sf2.openSession();
		t3 = ss2.beginTransaction();
		ss2.save(s2);
		t3.commit();
	}

	@Override
	public void delAddress(int aid) {
		// TODO Auto-generated method stub
		ss2 = sf2.openSession();
		t3 = ss2.beginTransaction();
		Address x3 = (Address)ss2.load(Address.class,aid);
		ss2.delete(x3);
		t3.commit();
	}

	public void updAddress(Address s2) {
		// TODO Auto-generated method stub
		ss2 = sf2.openSession();
		t3 = ss2.beginTransaction();
		Address x3 = (Address)ss2.load(Address.class,s2.getAid());
		x3.setName(s2.getName());
		x3.setPno(s2.getPno());
		x3.setPcode(s2.getPcode());
		x3.setCity(s2.getCity());
		x3.setArea(s2.getArea());
		x3.setAddress(s2.getAddress());
		x3.setLandmark(s2.getLandmark());
		x3.setApno(s2.getApno());
		ss2.saveOrUpdate(x3);
		t3.commit();

	}

	
	public Address viewAddressById(int aid) {
		// TODO Auto-generated method stub
		ss2 = sf2.openSession();
		t3 = ss2.beginTransaction();
		Address x3 = (Address)ss2.load(Address.class,aid);
		t3.commit();
		return x3;
	}

	
	public List<Address> viewAllAddress() {
		// TODO Auto-generated method stub
		ss2 = sf2.openSession();
		t3 = ss2.beginTransaction();
		List<Address> l2 = ss2.createCriteria(Address.class).list();
		t3.commit();
		return l2;
	}

	@Override
	public Address viewAddModelById(int aid) {
		// TODO Auto-generated method stub
		return null;
	}

	

}
