package shopify.DAO;

import java.util.List;

import shopify.Model.AddProduct;

public interface AddProductDAO {

	void addProduct(AddProduct p);
	void delProduct(String pid);
	void updProduct(AddProduct p);
	AddProduct viewProductById(String pid);
	List<AddProduct> viewAllProducts();

}
